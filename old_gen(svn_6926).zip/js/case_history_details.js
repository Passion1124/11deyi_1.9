$("header .back").on("click", function () {
    history.back()
})