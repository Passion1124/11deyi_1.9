$(function () {
    var token = getUrlParam("token");
    var paperid = getUrlParam("paperid");
    !token && (token = getLocalStroagelogin().token);
    var postData = {
        appToken : token,
        para: {
            device_type: "PC",
            device_id: "",
            api_version: "1.0.0.0",
            answerid: paperid
        }
    };
    $.ajax({
        url: ebase + "/api/LookUp/QueryAnswerByUidOrByIdOrForAll",
        type: "POST",
        data: postData,
        dataType: "json",
        success: function(data){
            console.log(data);
            if (data.Code === "0000"){
                var newData = JSON.parse(data.Data.Subs);
                var getTime = new Date(parseInt(data.Data.AnswerTime)).format("yyyy/M/d h:m");
                var content = JSON.parse(data.Data.PatientUserInfo);
                var sex = "男";
                if (content.sex === "W"){
                    sex = "女"
                }
                var bir = getBirthday(content.birthday);
                if (bir != "未填写"){
                    bir += "岁"
                }
                $(".info .content p:nth-of-type(2) span").text(content.name);
                $(".info .content p:nth-of-type(3) a").attr("href","tel:"+content.tel).text(content.tel);
                $(".info .content p:nth-of-type(4) span").text(bir);
                $(".info .content p:nth-of-type(5) span").text(sex);
                $(".info .top>div:last-of-type p:last-of-type").text("填表时间："+getTime);
                var imglength = $(".img_box").length;
                console.log(newData);
                for (var i = 0; i < newData.length; i++){
                    switch (newData[i].type) {
                        case "0":
                            var ele = "<p class='green'>"+newData[i].title+"</p>";
                            break;
                        case "1":
                        case "3":
                        case "4":
                            if (newData[i].answer.length > 0){
                                var ele = "<p>"+newData[i].title+"：<span>"+newData[i].answer[0]+"</span></p>";
                            }else {
                                var ele = "<p>"+newData[i].title+"：<span>未填写</span></p>";
                            }
                            break;
                        case "2":
                            if (newData[i].answer.length > 0){
                                var text = "";
                                for (var j = 0; j < newData[i].answer.length; j++){
                                    if (j != newData[i].answer.length - 1 ){
                                        text += newData[i].answer[j] + "、";
                                    }else {
                                        text += newData[i].answer[j];
                                    }
                                }
                                var ele = "<p>"+newData[i].title+"：<span>"+text+"</span></p>";
                            }else {
                                var ele = "";
                            }
                            break;
                        case "5":
                            if (newData[i].answer){
                                imglength++;
                                var imgwh = "1080x1920";
                                var img = "";
                                if (newData[i].answer.length > 0){
                                    for (var k = 0; k < newData[i].answer.length; k++){
                                        img += "<figure itemscope itemtype='1'>" +
                                            "<a id='minimg"+imglength+k+"' href='"+newData[i].answer[k]+"' itemprop='contentUrl' data-size='"+imgwh+"'>" +
                                            "<img src='"+newData[i].answer[k]+"' itemprop='thumbnail' alt='Image description'/>" +
                                            "</a>" +
                                            "<figcaption itemprop='caption description'>"+(k+1)+"</figcaption>" +
                                            "</figure>";
                                        var url = newData[i].answer[k];
                                        var k2=imglength+""+k;
                                        getImageWidth(url,k2,function(w,h,x){
                                            setTimeout(function () {
                                                var imgwh2=w+"x"+h;
                                                $("#minimg"+x).attr("data-size",imgwh2);
                                            }, 20)
                                        });
                                    }
                                    var imgBox = '<div class="Pics my-simple-gallery" itemscope itemtype="http://schema.org/ImageGallery">'+img+'</div>';
                                    var ele = "<div><p>"+newData[i].title+"：</p><div class='img_box'>"+imgBox+"</div></div>";
                                }else {
                                    var ele = "<div><p>"+newData[i].title+"：</p><p>暂无图片</p></div>";
                                }
                            }else {
                                var ele = "<div><p>"+newData[i].title+"：</p><p>暂无图片</p></div>";
                            }
                            break;
                    }
                    $(".num_one").append(ele);
                    $(".num_one").find(".green").prev().css({"padding-bottom":"1.2rem","border-bottom":"1px solid #ccc"});
                }
                if ($("img").length > 0){
                    initPhotoSwipeFromDOM('.my-simple-gallery');
                }
                getDetails(paperid,token, function (data) {
                    console.log(data);
                    if (data.Code === "0000"){
                        var myData = data.Data;
                        for (var z = 0; z < myData.length; z++){
                            if (myData[z].NoteResultInfo){
                                var ele = "<p>"+myData[z].Uname+"批注："+myData[z].NoteResultInfo+"</p>";
                                $(".diagnose_postil").append(ele);
                            }
                            if (myData[z].NoteCureInfo){
                                var ele = "<p>"+myData[z].Uname+"批注："+myData[z].NoteCureInfo+"</p>";
                                $(".cure_postil").append(ele);
                            }
                            if (myData[z].Pics.length > 0){
                                var img_postill = $(".img_postil>div").length;
                                var imageLength = imglength + img_postill + 1;
                                var imgwh = "1080x1920";
                                var img = "";
                                for (var x = 0; x < myData[z].Pics.length; x++){
                                    img += "<figure itemscope itemtype='1'>" +
                                        "<a id='minimg"+imageLength+x+"' href='"+myData[z].Pics[x]+"' itemprop='contentUrl' data-size='"+imgwh+"'>" +
                                        "<img src='"+myData[z].Pics[x]+"' itemprop='thumbnail' alt='Image description'/>" +
                                        "</a>" +
                                        "<figcaption itemprop='caption description'>"+(x+1)+"</figcaption>" +
                                        "</figure>";
                                    var url = myData[z].Pics[x];
                                    var k2=imageLength+""+x;
                                    getImageWidth(url,k2,function(w,h,x){
                                        setTimeout(function () {
                                            var imgwh2=w+"x"+h;
                                            $("#minimg"+x).attr("data-size",imgwh2);
                                        }, 20)
                                    });
                                }
                                var imgBox = '<div class="Pics my-simple-gallery" itemscope itemtype="http://schema.org/ImageGallery">'+img+'</div>';
                                var ele = "<div><p>"+myData[z].Uname+"批注：</p><div>"+imgBox+"</div></div>";
                                $(".img_postil").append(ele);
                                initPhotoSwipeFromDOM('.my-simple-gallery');
                            }
                        }
                        if ($(".postil .diagnose_postil p").length === 1){
                            $(".postil .diagnose_postil").addClass("hide");
                        }
                        if ($(".postil .cure_postil p").length === 1){
                            $(".postil .cure_postil").addClass("hide");
                        }
                        if ($(".postil .img_postil>div").length === 0){
                            $(".postil .img_postil").addClass("hide");
                        }
                        if ($(".postil .diagnose_postil p").length === 1 && $(".postil .cure_postil p").length === 1 && $(".postil .img_postil>div").length === 0){
                            $(".postil").addClass("hide");
                        }
                    }
                });
                getUserInfo(token,data.Data.PatientId, function (data) {
                    if (data.Code === "0000"){
                        var userData = data.Data;
                        $(".info .top>div:last-of-type p:nth-of-type(1)").text(userData.Name);
                        if (userData.FaceImgUrl){
                            $(".info .top .head_portrait").css("background-image","url("+userData.FaceImgUrl+")");
                        }else {
                            $(".info .top .head_portrait").css("background-image","url(http://www.11deyi.com/img/30.png)");
                        }
                    }
                    $(".loading_box").addClass("hide");
                });
            }
        },
        error: function (xhr ,errorType ,error){
            console.log(xhr);
            console.log(errorType);
            console.log(error)
        }
    })
});
function getUserInfo(token,id,callback){
    var postData = {
        "appToken": token,
        "para":{
            "device_type":"PC",
            "device_id":"",
            "api_version":"1.0.0.0",
            "search_userid": id
        }
    };
    //console.log(token);
    $.ajax({
        "url": ebase+ "/api/User/QueryUserById",
        "type":"POST",
        "dataType":"json",
        "data":postData,
        success:function(data){
            callback(data)
        },
        error: function(xhr ,errorType ,error){
            //alert("错误");
            console.log(xhr);
            console.log(errorType);
            console.log(error)
        }
    })
}
function getDetails(id,token,callback){
    var postData = {
        "appToken": token,
        "para":{
            "device_type":"PC",
            "device_id":"",
            "api_version":"1.0.0.0",
            "qid": id
        }
    };
    //console.log(token);
    $.ajax({
        "url": ebase+ "/api/Question/QueryQuestionNoteByQidWithUid",
        "type":"POST",
        "dataType":"json",
        "data":postData,
        success:function(data){
            callback(data)
        },
        error: function(xhr ,errorType ,error){
            //alert("错误");
            console.log(xhr);
            console.log(errorType);
            console.log(error)
        }
    })
}
function getBirthday(time){
    var myTime = parseInt(time);
    var myYear = "";
    if (isNaN(myTime) || !myTime){
        myYear = "未填写";
    }else {
        var localTime =  parseInt(new Date().format("yyyy"));
        var birTime = parseInt(new Date(parseInt(time)).format("yyyy"));
        myYear = localTime - birTime;
    }
    return myYear;
}